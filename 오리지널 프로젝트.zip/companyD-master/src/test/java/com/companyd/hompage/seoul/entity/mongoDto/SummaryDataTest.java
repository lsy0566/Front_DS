package com.companyd.hompage.seoul.entity.mongoDto;


public class SummaryDataTest {
}
