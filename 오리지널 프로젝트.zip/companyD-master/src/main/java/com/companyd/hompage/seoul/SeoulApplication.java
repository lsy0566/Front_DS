package com.companyd.hompage.seoul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeoulApplication {

    public static void main(String[] args) {
        SpringApplication.run(SeoulApplication.class, args);
    }

}
