package com.companyd.hompage.seoul.email;

public class EmailApplication {
}
