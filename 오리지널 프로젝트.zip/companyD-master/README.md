# Sixth-Sense 비식별 프로그램 Frontend
- 개발자
    - 노설
        + 20200604 
            + 업로드 파일 관련 file_info mybatis설정 및 DB 추가, 설정
            + 비식별 처리 관련 result_log mybatis설정 및 DB 추가, 설정
        + 20200606
            + 파일 다운로드 관련 API 처리 
            + 추후 파일 리스트와 result_log 테이블과 매핑시킬지의 여부 팀과 상의 예정
    - 이동욱
        + 20200605
            + 파일리스트 출력 반복문 기초 설정
        + 20200607
            + index 필요없는 부분 일부 삭제
            + 파일리스트 상세정보 페이지 생성 및 데이터 이동 확인
            + 메인 background 설정 및 summarydetail 
        + 20200608
            + mypage에 파일리스트 페이지 생성
            + username에 세션 유지한 상태로 가져옴  
    - 최민영
        + 20200605
            + MongoDB 셋팅
    
